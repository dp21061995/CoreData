
import UIKit

class ViewController: UIViewController {
    
    //MARK: - View Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = "Core Data"
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: - Button Action
    
    @IBAction func didTapAdd(_ sender: UIButton) {
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "addUserDetailVC") as! addUserDetailVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func didTapHistory(_ sender: UIButton) {
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "historyVC") as! historyVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

