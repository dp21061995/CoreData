
import UIKit

class historyCell: UITableViewCell {

    /* Label */
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblTechnology: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
