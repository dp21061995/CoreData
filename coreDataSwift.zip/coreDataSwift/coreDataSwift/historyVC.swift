
import UIKit
import  CoreData

class historyVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    //MARK: - Variable Declaration
    
    /* TableView */
    @IBOutlet weak var tblView: UITableView!
    
    /* Local Variable Declaration */
    var result = [Any]()
    
    //MARK: - View Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        let context = appDelegate.persistentContainer.viewContext
        
        //Fetch
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Users")
        //request.predicate = NSPredicate(format: "age = %@", "12")
        request.returnsObjectsAsFaults = false
        
        do {
            result = try context.fetch(request)
            //for data in result as! [NSManagedObject] {
            //   print(data.value(forKey: "name") as! String)
            // }
            
        } catch {
            
            print("Failed")
        }
        
        // self.navigationController?.isNavigationBarHidden = false
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: - Tableview Delegate and Datasource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return  result.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell: historyCell! = tableView.dequeueReusableCell(withIdentifier: "historyCell") as? historyCell
        
        let device = result[indexPath.row] as? NSManagedObject
        
        if let aKey = device?.value(forKey: "name") {
            
            cell.lblName.text = "\(aKey)"
        }
        if let aKey = device?.value(forKey: "technology") {
            
            cell.lblTechnology.text = "\(aKey)"
        }
        
        return cell
    }
}
