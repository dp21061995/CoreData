
import UIKit
import CoreData

class addUserDetailVC: UIViewController {
    
    //MARK: - Variable Declaration
    
    /* ImageView */
    @IBOutlet weak var imgProfile: UIImageView!
    
    /* Textfield */
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtTechnology: UITextField!
    
    //MARK: - View Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(addUserDetailVC.didTapProfile(_:)))
        imgProfile.addGestureRecognizer(tap)
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: - Button Action
    
    @IBAction func didTapSave(_ sender: UIButton) {
        
        if(txtName.text != "" && txtTechnology.text != "") {
            
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            
            let context = appDelegate.persistentContainer.viewContext
            
            let entity = NSEntityDescription.entity(forEntityName: "Users", in: context)
            let newUser = NSManagedObject(entity: entity!, insertInto: context)
            
            newUser.setValue(txtName.text!, forKey: "name")
            newUser.setValue(txtTechnology.text!, forKey: "technology")
            
            do {
                try context.save()
            } catch {
                print("Failed saving")
            }
            
            self.navigationController?.popViewController(animated: true)
        }
            
        else {
            let alert = UIAlertController(title: "Alert", message: "Enter Detail", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { action in
                switch action.style{
                case .default:
                    print("default")
                    
                case .cancel:
                    print("cancel")
                    
                case .destructive:
                    print("destructive")
                    
                    
                }}))
            self.present(alert, animated: true, completion: nil)
        }
        
    }
    
    @IBAction func didTapProfile(_ sender: UITapGestureRecognizer) {
        
        let optionMenu = UIAlertController(title: nil, message: "Select Photo", preferredStyle: .actionSheet)
        
        optionMenu.addAction(UIAlertAction(title: "Camera", style: .default, handler: {
            (alert: UIAlertAction!) -> Void in
            
            self.openCameraFor()
        }))
        
        optionMenu.addAction(UIAlertAction(title: "Gallery", style: .default, handler: {
            (alert: UIAlertAction!) -> Void in
            
            self.openGalleryFor()
        }))
        
        optionMenu.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: {
            (alert: UIAlertAction!) -> Void in
        }))
        
        self.present(optionMenu, animated: true, completion: nil)
    }
}

// MARK: - ImagePickerView Delegate

extension addUserDetailVC: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        let chosenImage = info[UIImagePickerControllerOriginalImage] as! UIImage
        
        imgProfile.image = chosenImage
        picker.dismiss(animated: true, completion: nil)
        
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        
        picker.dismiss(animated: true, completion: nil)
    }
}

// MARK: Private Helper Method

extension addUserDetailVC {
    
    func openCameraFor() {
        
        if UIImagePickerController.isCameraDeviceAvailable(.front) || UIImagePickerController.isCameraDeviceAvailable(.rear) {
            
            let picker = UIImagePickerController()
            picker.sourceType = .camera
            picker.delegate = self
          
            self.present(picker, animated: true, completion: nil)
        } else {
            
        }
    }
    
    func openGalleryFor() {
        
        let picker = UIImagePickerController()
        picker.sourceType = .photoLibrary;
        picker.delegate = self
        
        self.present(picker, animated: true, completion: nil)
    }
}
